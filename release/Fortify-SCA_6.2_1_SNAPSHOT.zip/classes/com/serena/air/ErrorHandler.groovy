package com.serena.air

class ErrorHandler {

    static discardExceptions(Closure closure, closureParams) {
        try {
            closure(closureParams)
        } catch (all) {
            println "Error: " + all.getMessage()
            System.exit(1)  
        }
    }
}
