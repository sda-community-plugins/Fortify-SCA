package com.serena.air.http

import com.serena.air.StepFailedException
import com.serena.air.UrlHelper
import com.urbancode.air.xtrust.XTrustProvider
import org.apache.http.HttpHost
import org.apache.http.auth.AuthScope
import org.apache.http.auth.UsernamePasswordCredentials
import org.apache.http.client.AuthCache
import org.apache.http.client.CredentialsProvider
import org.apache.http.client.methods.CloseableHttpResponse
import org.apache.http.client.methods.HttpRequestBase
import org.apache.http.client.protocol.HttpClientContext
import org.apache.http.client.utils.URIBuilder
import org.apache.http.config.Registry
import org.apache.http.config.RegistryBuilder
import org.apache.http.conn.socket.ConnectionSocketFactory
import org.apache.http.conn.socket.PlainConnectionSocketFactory
import org.apache.http.conn.ssl.NoopHostnameVerifier
import org.apache.http.conn.ssl.SSLConnectionSocketFactory

import org.apache.http.impl.auth.BasicScheme
import org.apache.http.impl.client.BasicAuthCache
import org.apache.http.impl.client.BasicCredentialsProvider
import org.apache.http.impl.client.CloseableHttpClient
import org.apache.http.impl.client.HttpClients
import org.apache.http.ssl.SSLContextBuilder
import org.apache.http.ssl.TrustStrategy
import org.apache.log4j.Logger

import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import java.security.cert.CertificateException
import java.security.cert.X509Certificate

abstract class HttpBaseClient {
    private static final Logger logger = Logger.getLogger(HttpBaseClient.class)

    public String username
    public String password
    public URI serverUri
    HttpHost host
    CloseableHttpClient httpclient
    HttpClientContext defaultContext

    HttpBaseClient(String serverUrl) {
        this(serverUrl, null, null)
    }

    HttpBaseClient(String serverUrl, String username, String password) {
        this.username = username
        this.password = password

        serverUri = new URI(getFullServerUrl(serverUrl))
        if(serverUri.getHost() == null){
            throw new StepFailedException("Cannot parse server url: $serverUrl")
        }
        host = new HttpHost((String)serverUri.getHost(), serverUri.getPort(), serverUri.getScheme())

        defaultContext = createContext()

        httpclient = HttpClients.createDefault()
    }

    public void setSSL(){
        SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
            @Override
            boolean isTrusted(X509Certificate[] x509Certificates, String s) throws CertificateException {
                return true;
            }
        }).build()

        HostnameVerifier hostnameVerifier = new NoopHostnameVerifier();
        SSLConnectionSocketFactory sslSocketFactory = new SSLConnectionSocketFactory(sslContext, hostnameVerifier);

        httpclient = HttpClients.custom()
                .setSslcontext(sslContext)
                .setSSLHostnameVerifier(hostnameVerifier)
                .setSSLSocketFactory(sslSocketFactory)
                .build()
    }

    public HttpClientContext createContext(){
        HttpClientContext context  = HttpClientContext.create();

        if(username){
            CredentialsProvider credsProvider = new BasicCredentialsProvider();
            credsProvider.setCredentials(
                    new AuthScope(serverUri.getHost(), serverUri.getPort()),
                    new UsernamePasswordCredentials(username, password))
            context.setCredentialsProvider(credsProvider);
        }
        return context
    }

    public void setPreemptiveAuth(){
        setPreemptiveAuth(defaultContext)
    }
    public void setPreemptiveAuth(HttpClientContext context){
        // setting auth cache (for preemptive auth)
        AuthCache authCache = new BasicAuthCache();
        BasicScheme basicAuth = new BasicScheme();
        authCache.put(host, basicAuth);
        context.setAuthCache(authCache)
    }

    public URIBuilder getUriBuilder(){
        return new URIBuilder(serverUri).setPath(serverUri.getPath())
    }
    public URIBuilder getUriBuilder(String pathAddition){
        String fullPath = UrlHelper.concatUrls(serverUri.getPath(), pathAddition)

        return new URIBuilder(serverUri).setPath(fullPath)
    }

    public HttpResponse exec(HttpRequestBase method){
        exec(method, defaultContext)
    }
    public HttpResponse exec(HttpRequestBase method, HttpClientContext context){
        logger.debug "Running request: ${method.getMethod()} ${method.getURI()}"

        CloseableHttpResponse apacheHttpResponse = httpclient.execute(host, method, context)
        HttpResponse serenaAirHttpResponse = new HttpResponse(apacheHttpResponse)

        logger.debug "Response code: ${serenaAirHttpResponse.code}"
        if(serenaAirHttpResponse.code != 404){
            logger.debug "Response body: ${serenaAirHttpResponse.body}"
        } else {
            logger.debug "Response body: 404 Not Found"
        }
        return serenaAirHttpResponse
    }

    abstract protected String getFullServerUrl(String serverUrl)

    public static void checkStatusCode(int code){
        if(code == 401){
            throw new StepFailedException("Authorization failed! Please check username and password parameters!")
        }
        if(code == 403){
            throw new StepFailedException("Access forbidden! Please check username and password parameters!")
        }
        if(code == 404){
            throw new StepFailedException("Resource not found")
        }
    }


}
